---
title: "Toward a Computational Framework for Tarot Semantics: A Structured 78-Card Dataset for NLP and Symbolic Reasoning"
author:
  - name: Selin Aura
    affiliation: Deckaura
    email: selin@deckaura.com
  - name: Deckaura Research
    affiliation: Deckaura
    url: https://deckaura.com
date: April 2026
---

# Abstract

Tarot, a 78-card symbolic system with origins in 15th-century European playing cards, has become a widely studied cultural and cognitive framework. Despite its prevalence in both popular divinatory practice and academic inquiry (e.g., Jungian psychology, narrative therapy, semiotics), no machine-readable, structured dataset of tarot card semantics exists in open research repositories. We present a curated 78-card dataset covering the complete Major and Minor Arcana, annotated across five interpretive dimensions (upright, reversed, love, career, yes/no), each linked to an extended natural-language guide. We discuss applications in zero-shot classification, symbolic embedding research, and narrative generation for AI assistants. The dataset is released under MIT license at [deckaura.com](https://deckaura.com), Hugging Face, and Zenodo.

# 1. Introduction

The tarot deck consists of 78 cards divided into the 22 Major Arcana (archetypal trumps) and 56 Minor Arcana (four suits of fourteen cards each). Since its standardization in the Rider-Waite-Smith tradition (1909), tarot has served simultaneously as a divinatory instrument, a psychological reflection tool [1], and a symbolic vocabulary for narrative exploration.

While tarot features prominently in cultural NLP studies (sentiment of symbolism, narrative mythology, ritual discourse), researchers lack a standardized, machine-readable resource. Existing tarot databases are either locked in proprietary apps or distributed as unstructured web pages. This paper introduces a structured, permissively licensed corpus addressing that gap.

# 2. Dataset Construction

We curated interpretations from the open guides hosted at https://deckaura.com, cross-referenced against the canonical Rider-Waite-Smith Little White Book (1909) and contemporary interpretive traditions. Each of the 78 cards is annotated with:

- **Upright meaning** (primary interpretation when drawn normally)
- **Reversed meaning** (interpretation when inverted)
- **Love context** (interpersonal/romantic)
- **Career context** (material/professional)
- **Yes/No verdict** (binary for decision queries)
- **Element** (Fire / Water / Air / Earth)
- **Zodiac association** (planetary or sign correspondence)
- **Guide URL** (full extended interpretation)

Formats: CSV, JSONL, JSON. Each entry averages 150 characters of interpretive text per dimension; the guide URL provides approximately 1,500–3,000 words of context per card.

# 3. Example Applications

**3.1 Zero-shot classification.** Given the 78 upright meanings as label descriptions, unseen text can be classified against the closest tarot archetype using any sentence-embedding model (e.g., SBERT, OpenAI `text-embedding-3-small`). This is useful for symbolic narrative analysis or mood detection tasks.

**3.2 Retrieval-augmented generation (RAG).** The dataset, combined with the extended guide URLs, provides high-quality retrieval context for LLM-powered tarot reading assistants. Our reference implementation as a Model Context Protocol (MCP) server is at https://github.com/gokimedia/tarot-mcp-server.

**3.3 Symbolic embedding research.** The four elements × four suits × fourteen rank structure of the Minor Arcana provides a constrained symbolic lattice for studying how language models represent combinatorial symbolism.

**3.4 Narrative therapy tooling.** Jungian clinicians and coaches use tarot as a projective instrument [1]; a structured corpus enables reproducible research on linguistic framing effects.

# 4. Licensing and Availability

- **License:** MIT
- **Primary source:** https://deckaura.com/blogs/guide/tarot-card-meanings
- **Hugging Face:** https://huggingface.co/datasets/deckaura/tarot-card-meanings
- **Zenodo DOI:** (this record)
- **Reference implementation (MCP server):** https://github.com/gokimedia/tarot-mcp-server
- **Wikidata:** https://www.wikidata.org/wiki/Q138745960

# 5. Ethical Considerations

Tarot is a cultural and divinatory practice. This dataset does not endorse any metaphysical claim; it provides a structured representation of interpretive traditions for research and tooling. Downstream systems should not present tarot output as deterministic prediction. Our reference tools at https://deckaura.com include explicit disclaimers.

# 6. Conclusion

We release the first open, structured, DOI-citable 78-card tarot semantics dataset. We invite the NLP, symbolic AI, and digital humanities communities to build upon it.

# References

[1] Nichols, S. (1980). *Jung and Tarot: An Archetypal Journey*. Samuel Weiser.
[2] Waite, A. E. (1909). *The Pictorial Key to the Tarot*. William Rider & Son.
[3] Place, R. M. (2005). *The Tarot: History, Symbolism, and Divination*. Tarcher/Penguin.
[4] Kaplan, S. R. (1978). *The Encyclopedia of Tarot, Volume I*. U.S. Games Systems.

---
**Corresponding author:** Selin Aura, Deckaura, https://deckaura.com
